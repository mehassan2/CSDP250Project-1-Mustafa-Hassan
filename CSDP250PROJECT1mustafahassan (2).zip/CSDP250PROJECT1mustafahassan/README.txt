CSDP Project #1

Project Description:
This project implements a linked list in C++ to manage and store information about the courses a student has taken in their bachelor's program. Each course is represented by a node that includes the course code, credit hours, and grade.

Input Data:
The program prompts the user to enter the following information for each course:
- Course Code: A string representing the course identifier (e.g., "CSDP 250").
- Credit Hours: An integer representing the number of credit hours for the course.
- Grade: A character representing the grade received (e.g., "A", "B", etc.).

The user is prompted to enter a total of 10 courses.

Output Result:
The program displays the list of courses after they are entered and then allows the user to delete two courses by entering their course codes. After each deletion, the updated list of courses is displayed.

Example Output:
Enter course code: CSDP 250
Enter credit hours: 3
Enter grade (as a character): A

Enter course code: MATH 232
Enter credit hours: 3
Enter grade (as a character): B

...

Course list before deletion:
Course: CSDP 250, Credits: 3, Grade: A
Course: MATH 232, Credits: 3, Grade: B
...

Enter course code to delete: CSDP 250

Course list after deletion:
Course: MATH 232, Credits: 3, Grade: B

Procedures to Run the Program in Visual Studio:
1. Open the Solution:
   - Open Visual Studio.
   - Click on File > Open > Project/Solution and select your project file (.sln).

2. Build the Solution:
   - Go to Build > Build Solution or press Ctrl + Shift + B to compile the program.

3. Run the Program:
   - Start the program by clicking on the Start button (or press F5).
   - Make sure to select Console Application if prompted.

4. Follow the Prompts:
   - Enter the course details when prompted.
   - After entering 10 courses, you will be prompted to delete two courses by entering their course codes.

File Structure:
- main.cpp: Contains the main program logic, including course management functionalities.
- class_head.h: (if applicable) Contains the declaration of the CourseNode structure and CourseList class.
- class_functions.cpp: (if applicable) Contains the implementation of the CourseList methods.
- README.txt: Project documentation (this file).

Additional Notes:
- Ensure that course codes entered contain valid numeric parts for sorting.
- The program currently handles basic error checking for course codes without numeric parts.
