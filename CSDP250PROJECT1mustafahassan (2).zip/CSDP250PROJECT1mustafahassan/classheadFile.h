// classheadFile.h
#ifndef CLASS_HEAD_FILE_H
#define CLASS_HEAD_FILE_H

#include <string>

struct CourseNode {
    std::string courseCode;  // Course identifier (e.g., "CSDP 250")
    int creditHours;         // Number of credit hours for the course
    char grade;              // Grade received (e.g., 'A', 'B', etc.)
    CourseNode* next;        // Pointer to the next node in the linked list
};

class CourseList {
private:
    CourseNode* head;        // Pointer to the head of the linked list

    // Helper function to extract the numeric part of the course code
    int extractCourseNumber(const std::string& courseCode);

public:
    // Constructor and Destructor
    CourseList();
    ~CourseList();

    // Public methods for course management
    void addCourse(std::string code, int hours, char grd);
    void deleteCourse(std::string courseCode);
    void deleteAllNodes();
    void displayCourses();
};

#endif // CLASS_HEAD_FILE_H

