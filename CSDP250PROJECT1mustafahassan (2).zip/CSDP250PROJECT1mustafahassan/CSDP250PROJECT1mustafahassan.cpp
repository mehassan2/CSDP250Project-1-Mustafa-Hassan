#include <iostream>
#include <string>
using namespace std;

// Define the CourseNode structure
struct CourseNode {
    string courseCode;
    int creditHours;
    char grade;
    CourseNode* next;
};

// Linked list class to manage courses
class CourseList {
private:
    CourseNode* head;

    // Function to extract the numeric part of the course code (e.g., "250" from "CSDP 250")
    int extractCourseNumber(const string& courseCode) {
        string numberPart;
        for (char ch : courseCode) {
            if (isdigit(ch)) {
                numberPart += ch;
            }
        }

        // Check if numberPart is empty before converting to int
        if (!numberPart.empty()) {
            return stoi(numberPart);  // Convert string of digits to int
        }
        else {
            // Handle case where no digits are found
            cerr << "Warning: No numeric part found in course code: " << courseCode << endl;
            return -1; // Return a value indicating an error
        }
    }

public:
    // Constructor
    CourseList() {
        head = nullptr;
    }

    // Destructor to delete all nodes
    ~CourseList() {
        deleteAllNodes();
    }

    // Function to add a course at the correct position (sorted by course number)
    void addCourse(string code, int hours, char grd) {
        CourseNode* newNode = new CourseNode{ code, hours, grd, nullptr };
        int newCourseNumber = extractCourseNumber(code);  // Extract number part

        // Only add the course if the extraction was successful
        if (newCourseNumber != -1) {
            if (!head || extractCourseNumber(head->courseCode) > newCourseNumber) {
                // Insert at head if list is empty or new course has a smaller number
                newNode->next = head;
                head = newNode;
            }
            else {
                CourseNode* current = head;
                while (current->next && extractCourseNumber(current->next->courseCode) < newCourseNumber) {
                    current = current->next;
                }
                newNode->next = current->next;
                current->next = newNode;
            }
        }
        else {
            // Handle the situation when the course cannot be added due to invalid number
            delete newNode; // Clean up the newly allocated node
            cout << "Course not added due to invalid course code: " << code << endl;
        }
    }

    // Function to delete a course by course code
    void deleteCourse(string courseCode) {
        if (!head) return;

        if (head->courseCode == courseCode) {  // Delete head node
            CourseNode* temp = head;
            head = head->next;
            delete temp;
        }
        else {
            CourseNode* current = head;
            while (current->next && current->next->courseCode != courseCode) {
                current = current->next;
            }
            if (current->next) {
                CourseNode* temp = current->next;
                current->next = current->next->next;
                delete temp;
            }
        }
    }

    // Function to delete all nodes (called in the destructor)
    void deleteAllNodes() {
        while (head) {
            CourseNode* temp = head;
            head = head->next;
            delete temp;
        }
    }

    // Function to display all courses
    void displayCourses() {
        CourseNode* current = head;
        while (current) {
            cout << "Course: " << current->courseCode
                << ", Credits: " << current->creditHours
                << ", Grade: " << current->grade << endl;
            current = current->next;
        }
    }
};

int main() {
    CourseList courseList;

    // Add courses (prompt user for 10 courses)
    for (int i = 0; i < 10; ++i) {
        string code;
        int credits;
        char grade;

        cout << "Enter course code: ";
        getline(cin >> ws, code);  // Use getline to capture the entire course code

        cout << "Enter credit hours: ";
        cin >> credits;

        cout << "Enter grade (as a character): ";
        cin >> grade;

        courseList.addCourse(code, credits, grade);
    }

    // Display the list of courses before deletion
    cout << "\nCourse list before deletion:" << endl;
    courseList.displayCourses();

    // Ask the user to delete two courses
    string courseToDelete;
    for (int i = 0; i < 2; ++i) {
        cout << "\nEnter course code to delete: ";
        getline(cin >> ws, courseToDelete);  // Use getline for course code input
        courseList.deleteCourse(courseToDelete);

        // Display the list of courses after each deletion
        cout << "\nCourse list after deletion:" << endl;
        courseList.displayCourses();
    }

    return 0;
}

