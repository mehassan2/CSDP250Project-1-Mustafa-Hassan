// classfunctionFile.cpp
#include "classheadFile.h"
#include <iostream>
#include <cctype> // for isdigit
using namespace std;

// Constructor
CourseList::CourseList() {
    head = nullptr;
}

// Destructor to delete all nodes
CourseList::~CourseList() {
    deleteAllNodes();
}

// Function to extract the numeric part of the course code
int CourseList::extractCourseNumber(const string& courseCode) {
    string numberPart;
    for (char ch : courseCode) {
        if (isdigit(ch)) {
            numberPart += ch;
        }
    }

    // Check if numberPart is empty before converting to int
    if (!numberPart.empty()) {
        return stoi(numberPart);
    }
    else {
        cerr << "Warning: No numeric part found in course code: " << courseCode << endl;
        return -1; // Indicate an error
    }
}

// Function to add a course at the correct position (sorted by course number)
void CourseList::addCourse(string code, int hours, char grd) {
    CourseNode* newNode = new CourseNode{ code, hours, grd, nullptr };
    int newCourseNumber = extractCourseNumber(code);

    if (newCourseNumber != -1) {
        if (!head || extractCourseNumber(head->courseCode) > newCourseNumber) {
            // Insert at head if list is empty or new course has a smaller number
            newNode->next = head;
            head = newNode;
        }
        else {
            CourseNode* current = head;
            while (current->next && extractCourseNumber(current->next->courseCode) < newCourseNumber) {
                current = current->next;
            }
            newNode->next = current->next;
            current->next = newNode;
        }
    }
    else {
        delete newNode; // Clean up if extraction fails
        cout << "Course not added due to invalid course code: " << code << endl;
    }
}

// Function to delete a course by course code
void CourseList::deleteCourse(string courseCode) {
    if (!head) return;

    if (head->courseCode == courseCode) {  // Delete head node
        CourseNode* temp = head;
        head = head->next;
        delete temp;
    }
    else {
        CourseNode* current = head;
        while (current->next && current->next->courseCode != courseCode) {
            current = current->next;
        }
        if (current->next) {
            CourseNode* temp = current->next;
            current->next = current->next->next;
            delete temp;
        }
    }
}

// Function to delete all nodes
void CourseList::deleteAllNodes() {
    while (head) {
        CourseNode* temp = head;
        head = head->next;
        delete temp;
    }
}

// Function to display all courses
void CourseList::displayCourses() {
    CourseNode* current = head;
    while (current) {
        cout << "Course: " << current->courseCode
            << ", Credits: " << current->creditHours
            << ", Grade: " << current->grade << endl;
        current = current->next;
    }
}
