// mainfunctionFile.cpp
#include <iostream>
#include "classheadFile.h"
using namespace std;

int main() {
    CourseList courseList;

    // Add courses (prompt user for 10 courses)
    for (int i = 0; i < 10; ++i) {
        string code;
        int credits;
        char grade;

        cout << "Enter course code: ";
        getline(cin >> ws, code);  // Use getline to capture the entire course code

        cout << "Enter credit hours: ";
        cin >> credits;

        cout << "Enter grade (as a character): ";
        cin >> grade;

        courseList.addCourse(code, credits, grade);
    }

    // Display the list of courses before deletion
    cout << "\nCourse list before deletion:" << endl;
    courseList.displayCourses();

    // Ask the user to delete two courses
    string courseToDelete;
    for (int i = 0; i < 2; ++i) {
        cout << "\nEnter course code to delete: ";
        getline(cin >> ws, courseToDelete);  // Use getline for course code input
        courseList.deleteCourse(courseToDelete);

        // Display the list of courses after each deletion
        cout << "\nCourse list after deletion:" << endl;
        courseList.displayCourses();
    }

    return 0;
}
